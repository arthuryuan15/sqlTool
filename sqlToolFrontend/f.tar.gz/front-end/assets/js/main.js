// close command page
function myFunction() {
    var x = document.getElementsByClassName("functionPage");
    var y = document.getElementsByClassName("welcome");
    console.log(x);
    console.log(x[0].style);
    if (x[0].style.display === "none") {
      x[0].style.display = "block";
      y[0].style.display="none";
    } else {
      x[0].style.display = "none";
      y[0].style.display="block";
    }
  }

// open queries command page
  function openQueries() {
      var functionPage = document.getElementsByClassName("functionPage");
      var welcome = document.getElementsByClassName("welcome");
      functionPage[0].style.display = "block";
      welcome[0].style.display = "none";
  }

// clean function
function clearFunction() {
  var x = document.getElementById('queryInput');
  document.getElementById('queryInput').value = '';
  console.log(x);
}


// excute
function excute1(){

  var x = document.getElementById('queryInput');
  var queryResult = document.getElementById('queryResult');

var xhr = new XMLHttpRequest();
        xhr.open('post','http://1.117.200.132:8080/sqlTools/api/query',true)
        // 接收返回值
        xhr.onreadystatechange = function(){
            if(xhr.readyState === 4 ){
                if(xhr.status >= 200){
                    console.log(xhr.responseText);
                }
            }
        }
        // 处理请求参数
        postData = {"1":"2"};
        postData = (function(value){
        var dataString = "";
        for(var key in value){
             dataString += key+"="+value[key]+"&";
        };
          return dataString;
        }(postData));
        // 设置请求头
        xhr.setRequestHeader("Content-type","application/json");
        // 异常处理
        xhr.onerror = function() {
           console.log('Network request failed')
        }
        // 发出请求
        xhr.send(postData);

  
  // xhr.responseType = 'json';
  // fetch('http://127.0.0.1:8080/sqlTools/api/query',{

  //   method:'POST',
  //   body: JSON.stringify({sqlCommand: x.value}),
  //   headers: new Headers({'content-type': 'application/json'}),
  //   mode: 'no-cors'

  //   }).then(response => {
  //     if(response.ok){
  //       console.log(response.json);
  //       return response.json();
  //     }
  //     throw new Error('Request failed');
  //   }).then( jsonResponse => {
  //     console.log(jsonResponse);
  //   });
  
}

// 
function excute(){
  var x = document.getElementById('queryInput');
  var xmlhttp = new XMLHttpRequest();   // new HttpRequest instance 
  var theUrl = "http://1.117.200.132:8080/sqlTools/api/query";

  xmlhttp.open("POST", theUrl);
  xmlhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
  xmlhttp.send(JSON.stringify({sqlCommand: x.value}));

  xmlhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
        console.log(typeof this.response);
        const obj = JSON.parse(this.response);
        console.log(obj.data);
        const data = obj.data;
        
        var strCommand = "Command executed ";
        var strTime = "Measured time: ";
        var strAffected = "";
        
        if(data.commandStatus){
          strCommand += "successfully. ";
        }else{
          strCommand += "failed. ";
        }

        if(data.measuredTime > 0){
          strTime += data.measuredTime + " [ms] ";
        }else{
          strTime += "0 [ms]";
        }
        if(data.affectedRowNum >= 0){
          strAffected += data.affectedRowNum + " rows affected. ";
        }else{
          strAffected += "-1 rows affected.";
        }
        var res = strCommand + strTime + strAffected;

        document.getElementById('queryResult').innerHTML = res;
    }
  };
  
  var Str = "Command executed" ;

  document.getElementById('queryResult').value = '';
  

}