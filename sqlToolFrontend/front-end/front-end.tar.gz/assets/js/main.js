// close command page
function myFunction() {
    var x = document.getElementsByClassName("functionPage");
    var y = document.getElementsByClassName("welcome");
    console.log(x);
    console.log(x[0].style);
    if (x[0].style.display === "none") {
      x[0].style.display = "block";
      y[0].style.display="none";
    } else {
      x[0].style.display = "none";
      y[0].style.display="block";
    }
  }

// open queries command page
  function openQueries() {
      var functionPage = document.getElementsByClassName("functionPage");
      var welcome = document.getElementsByClassName("welcome");
      functionPage[0].style.display = "block";
      welcome[0].style.display = "none";
  }


// clean function
function clearFunction() {
  var x = document.getElementById('queryInput');
  document.getElementById('queryInput').value = '';
  console.log(x);
}
